﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace EmpService
{
    public static class DL_EmpDetails
    {

        static string connection = ConfigurationManager.AppSettings["sqlConnection"].ToString();

        public static int add(EmpDetails empData)
        {
            int result = 0;
            if (validateData(empData))
            {
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();
                    string qrycmd = "INSERT into EmpTable values (@EmpID,@EmpName,@EmpAddress)";
                    SqlCommand cmd = new SqlCommand(qrycmd, conn);
                    cmd.Parameters.Add("@EmpID", System.Data.SqlDbType.VarChar).Value = empData.EmpId;
                    cmd.Parameters.Add("@EmpName", System.Data.SqlDbType.VarChar).Value = empData.EmpName == string.Empty ? empData.EmpId : empData.EmpName;
                    cmd.Parameters.Add("@EmpAddress", System.Data.SqlDbType.VarChar).Value = empData.EmpName == string.Empty ? "" :  empData.EmpAddress;
                    result = cmd.ExecuteNonQuery();
                }
            }
            return result;
        }
        public static int update(EmpDetails empData)
        {
            int result = 0;
            if (validateData(empData))
            {
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();
                    string qrycmd = "UPDATE EmpTable SET EmpName=@EmpName,EmpAddress=@EmpAddress where EmpID=@EmpID";
                    SqlCommand cmd = new SqlCommand(qrycmd, conn);
                    cmd.Parameters.Add("@EmpID", System.Data.SqlDbType.VarChar).Value = empData.EmpId;
                    cmd.Parameters.Add("@EmpName", System.Data.SqlDbType.VarChar).Value = empData.EmpName == string.Empty ? empData.EmpId : empData.EmpName;
                    cmd.Parameters.Add("@EmpAddress", System.Data.SqlDbType.VarChar).Value = empData.EmpName == string.Empty ? "" : empData.EmpAddress;
                    result = cmd.ExecuteNonQuery();
                }
            }
            return result;
        }

        static bool validateData(EmpDetails empData)
        {
            bool valid = true;

            if (string.IsNullOrEmpty(empData.EmpId))
                valid = false;

            return valid;

        }
        public static int delete(EmpDetails empData)
        {
            int result = 0;
            if (validateData(empData))
            {
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();
                    string qrycmd = "DELETE FROM EmpTable where EmpID=@EmpID";  
                    SqlCommand cmd = new SqlCommand(qrycmd, conn);
                    cmd.Parameters.Add("@EmpID", System.Data.SqlDbType.VarChar).Value = empData.EmpId;                 
                    result = cmd.ExecuteNonQuery();
                }
            }
            return result;
        }
        public static DataSet selectEmpDetails(EmpDetails empData)
        {
            DataSet ds = new DataSet();
            if (validateData(empData))
            {
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();
                    string qrycmd = "SELECT * FROM EmpTable WHERE EmpID=@EmpID";
                    SqlCommand cmd = new SqlCommand(qrycmd, conn);
                    cmd.Parameters.Add("@EmpID", System.Data.SqlDbType.VarChar).Value = empData.EmpId;
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);

                    sda.Fill(ds);
                    cmd.ExecuteNonQuery();
                }
            }
            return ds;
        }
        public static DataSet selectAllEmpDetails()
        {
            DataSet ds = new DataSet();
            using (SqlConnection conn = new SqlConnection(connection))
            {
                conn.Open();
                string qrycmd = "SELECT * FROM EmpTable ORDER BY EmpID ASC";
                SqlCommand cmd = new SqlCommand(qrycmd, conn);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(ds);
                cmd.ExecuteNonQuery();
            }
            return ds;
        }
    }
}