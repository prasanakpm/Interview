﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace EmpService
{

    [ServiceContract]
    public interface IEmpService
    {
        [OperationContract]
        string InsertEmpDetails(EmpDetails empData);

        [OperationContract]
        string DeleteEmpDetails(EmpDetails empData);

        [OperationContract]
        string UpdateEmpDetails(EmpDetails empData);

        [OperationContract]
        DataSet SelectEmpDetails(EmpDetails empData);


        [OperationContract]
        DataSet SelectAllEmpDetails();

    }

    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "EmpService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select EmpService.svc or EmpService.svc.cs at the Solution Explorer and start debugging.
    public class EmpService : IEmpService
    {
        
        public string InsertEmpDetails(EmpDetails empData)
        {
            try
            {
                int result = DL_EmpDetails.add(empData);

                if (result == 1)
                    return "Success";
                else
                    return "Fail";
            }
            catch (Exception)
            {
                return "Fail";

            }

        }

        public DataSet SelectEmpDetails(EmpDetails empData)
        {
            try
            {
                DataSet empDS = new DataSet();
                empDS = DL_EmpDetails.selectEmpDetails(empData);

                if (empDS != null)
                    return empDS;
                else
                    return null;

            }
            catch (Exception)
            {
                return null;

            }
        }
        public DataSet SelectAllEmpDetails()
        {
            try
            {
                DataSet empDS = new DataSet();
                empDS = DL_EmpDetails.selectAllEmpDetails();

                if (empDS != null)
                    return empDS;
                else
                    return null;

            }
            catch (Exception)
            {
                return null;

            }
        }
        public string DeleteEmpDetails(EmpDetails empData)
        {
            try
            {
                int result = DL_EmpDetails.delete(empData);

                if (result == 1)
                    return "Success";
                else
                    return "Fail";
            }
            catch (Exception)
            {
                return "Fail";

            }
        }

        public string UpdateEmpDetails(EmpDetails empData)
        {
            try
            {
                int result = DL_EmpDetails.update(empData);

                if (result == 1)
                    return "Success";
                else
                    return "Fail";
            }
            catch (Exception)
            {
                return "Fail";

            }
        }

    }

    [DataContract]
    public class EmpDetails
    {
        string empId;
        string empName;
        string empAddress;

        [DataMember]
        public string EmpId
        {
            get { return empId; }
            set { empId = value; }
        }

        [DataMember]
        public string EmpName
        {
            get { return empName; }
            set { empName = value; }
        }

        [DataMember]
        public string EmpAddress
        {
            get { return empAddress; }
            set { empAddress = value; }
        }
    }
}
