﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeeInfo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        EmpWCFServiceReference.EmpServiceClient empClientObj = new EmpWCFServiceReference.EmpServiceClient();
        EmpWCFServiceReference.EmpDetails empDataObj = new EmpWCFServiceReference.EmpDetails();

        public MainWindow()
        {
            InitializeComponent();
            ShowEmpDetails();
        }

        private void ShowEmpDetails()
        {
            try
            {
                DataSet empDetails = new DataSet();
                empDetails = empClientObj.SelectAllEmpDetails();
                gvData.ItemsSource = empDetails.Tables[0].AsDataView();

                if (empDetails.Tables[0].Rows.Count > 0)
                {
                    lblCount.Visibility = System.Windows.Visibility.Hidden;
                    gvData.Visibility = System.Windows.Visibility.Visible;
                }
                else
                {
                    lblCount.Visibility = System.Windows.Visibility.Visible;
                    gvData.Visibility = System.Windows.Visibility.Hidden;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        bool validate()
        {
            if (string.IsNullOrEmpty(txtEmpId.Text.Trim().ToString()))
            {
                MessageBox.Show("Employee ID should not be empty");
                return false;
            }
            else
                return true;
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (validate())
                {


                    empDataObj.EmpId = txtEmpId.Text.Trim().ToString().ToUpper();
                    empDataObj.EmpName = txtEmpName.Text.Trim().ToString();
                    empDataObj.EmpAddress = txtAddress.Text.Trim().ToString();

                    DataSet ds = empClientObj.SelectEmpDetails(empDataObj);
                    if(ds.Tables[0].Rows.Count>0)
                    {
                        MessageBox.Show("Employee ID already exist!");
                        return;
                    }

                    string output = empClientObj.InsertEmpDetails(empDataObj);
                    ShowResult(output, "Inserted");
                    ShowEmpDetails();
                    clearValues();
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        private static void ShowResult(string output, string Msg)
        {
            if (output == "Success")
                MessageBox.Show("Record " + Msg);
            else if (output == "Fail")
                MessageBox.Show("Record Failed");
            else
                MessageBox.Show("Invalid Opertaion");
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (validate())
                {
                    empDataObj.EmpId = txtEmpId.Text.Trim().ToString();
                    empDataObj.EmpName = txtEmpName.Text.Trim().ToString();
                    empDataObj.EmpAddress = txtAddress.Text.Trim().ToString();
                    string output = empClientObj.UpdateEmpDetails(empDataObj);
                    ShowResult(output, "Updated");
                    ShowEmpDetails();
                    clearValues();
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (validate())
                {
                    empDataObj.EmpId = txtEmpId.Text.Trim().ToString();
                    empDataObj.EmpName = txtEmpName.Text.Trim().ToString();
                    empDataObj.EmpAddress = txtAddress.Text.Trim().ToString();
                    string output = empClientObj.DeleteEmpDetails(empDataObj);
                    ShowResult(output, "Deleted");
                    ShowEmpDetails();
                    clearValues();
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            clearValues();
        }

        private void clearValues()
        {
            txtEmpId.Text = string.Empty;
            txtEmpName.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtEmpId.IsEnabled = true;
            btnAdd.IsEnabled = true;
        }


        private void gvData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                
                DataRowView rowview = gvData.SelectedItem as DataRowView;
                if (rowview != null)
                {
                    txtEmpId.Text = rowview.Row["EmpId"].ToString();
                    txtEmpName.Text = rowview.Row["EmpName"].ToString();
                    txtAddress.Text = rowview.Row["EmpAddress"].ToString();
                    txtEmpId.IsEnabled = false;
                    btnAdd.IsEnabled = false;
                }
            }

            catch (Exception)
            {

                throw;
            }
        }
    }
}
